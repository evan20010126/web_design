﻿
Partial Class WebControls
    Inherits System.Web.UI.Page

End Class
