﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Blackjack
   Inherits System.Windows.Forms.Form

   'Form overrides dispose to clean up the component list.
   <System.Diagnostics.DebuggerNonUserCode()> _
   Protected Overrides Sub Dispose(ByVal disposing As Boolean)
      Try
         If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
         End If
      Finally
         MyBase.Dispose(disposing)
      End Try
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> _
   Private Sub InitializeComponent()
      Me.playerTotalLabel = New System.Windows.Forms.Label()
      Me.dealerTotalLabel = New System.Windows.Forms.Label()
      Me.statusPictureBox = New System.Windows.Forms.PictureBox()
      Me.stayButton = New System.Windows.Forms.Button()
      Me.hitButton = New System.Windows.Forms.Button()
      Me.dealButton = New System.Windows.Forms.Button()
      Me.pictureBox22 = New System.Windows.Forms.PictureBox()
      Me.pictureBox21 = New System.Windows.Forms.PictureBox()
      Me.pictureBox20 = New System.Windows.Forms.PictureBox()
      Me.pictureBox19 = New System.Windows.Forms.PictureBox()
      Me.pictureBox18 = New System.Windows.Forms.PictureBox()
      Me.pictureBox17 = New System.Windows.Forms.PictureBox()
      Me.pictureBox16 = New System.Windows.Forms.PictureBox()
      Me.pictureBox15 = New System.Windows.Forms.PictureBox()
      Me.pictureBox14 = New System.Windows.Forms.PictureBox()
      Me.pictureBox13 = New System.Windows.Forms.PictureBox()
      Me.pictureBox12 = New System.Windows.Forms.PictureBox()
      Me.pictureBox11 = New System.Windows.Forms.PictureBox()
      Me.pictureBox10 = New System.Windows.Forms.PictureBox()
      Me.pictureBox9 = New System.Windows.Forms.PictureBox()
      Me.pictureBox8 = New System.Windows.Forms.PictureBox()
      Me.pictureBox7 = New System.Windows.Forms.PictureBox()
      Me.pictureBox6 = New System.Windows.Forms.PictureBox()
      Me.pictureBox5 = New System.Windows.Forms.PictureBox()
      Me.pictureBox4 = New System.Windows.Forms.PictureBox()
      Me.pictureBox3 = New System.Windows.Forms.PictureBox()
      Me.pictureBox2 = New System.Windows.Forms.PictureBox()
      Me.pictureBox1 = New System.Windows.Forms.PictureBox()
      Me.playerLabel = New System.Windows.Forms.Label()
      Me.dealerLabel = New System.Windows.Forms.Label()
      Me.SuspendLayout()
      '
      'playerTotalLabel
      '
      Me.playerTotalLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.playerTotalLabel.ForeColor = System.Drawing.Color.White
      Me.playerTotalLabel.Location = New System.Drawing.Point(550, 451)
      Me.playerTotalLabel.Name = "playerTotalLabel"
      Me.playerTotalLabel.Size = New System.Drawing.Size(123, 23)
      Me.playerTotalLabel.TabIndex = 151
      Me.playerTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'dealerTotalLabel
      '
      Me.dealerTotalLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.dealerTotalLabel.ForeColor = System.Drawing.Color.White
      Me.dealerTotalLabel.Location = New System.Drawing.Point(550, 421)
      Me.dealerTotalLabel.Name = "dealerTotalLabel"
      Me.dealerTotalLabel.Size = New System.Drawing.Size(123, 23)
      Me.dealerTotalLabel.TabIndex = 150
      Me.dealerTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'statusPictureBox
      '
      Me.statusPictureBox.Location = New System.Drawing.Point(537, 294)
      Me.statusPictureBox.Name = "statusPictureBox"
      Me.statusPictureBox.Size = New System.Drawing.Size(144, 120)
      Me.statusPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
      Me.statusPictureBox.TabIndex = 149
      Me.statusPictureBox.TabStop = False
      '
      'stayButton
      '
      Me.stayButton.BackColor = System.Drawing.SystemColors.ButtonFace
      Me.stayButton.Enabled = False
      Me.stayButton.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.stayButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.stayButton.Location = New System.Drawing.Point(553, 217)
      Me.stayButton.Name = "stayButton"
      Me.stayButton.Size = New System.Drawing.Size(112, 56)
      Me.stayButton.TabIndex = 148
      Me.stayButton.Text = "Stay"
      Me.stayButton.UseVisualStyleBackColor = False
      '
      'hitButton
      '
      Me.hitButton.BackColor = System.Drawing.SystemColors.ButtonFace
      Me.hitButton.Enabled = False
      Me.hitButton.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.hitButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.hitButton.Location = New System.Drawing.Point(553, 140)
      Me.hitButton.Name = "hitButton"
      Me.hitButton.Size = New System.Drawing.Size(112, 56)
      Me.hitButton.TabIndex = 147
      Me.hitButton.Text = "Hit"
      Me.hitButton.UseVisualStyleBackColor = False
      '
      'dealButton
      '
      Me.dealButton.BackColor = System.Drawing.SystemColors.ButtonFace
      Me.dealButton.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.dealButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.dealButton.Location = New System.Drawing.Point(553, 62)
      Me.dealButton.Name = "dealButton"
      Me.dealButton.Size = New System.Drawing.Size(112, 56)
      Me.dealButton.TabIndex = 146
      Me.dealButton.Text = "Deal"
      Me.dealButton.UseVisualStyleBackColor = False
      '
      'pictureBox22
      '
      Me.pictureBox22.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox22.Location = New System.Drawing.Point(464, 470)
      Me.pictureBox22.Name = "pictureBox22"
      Me.pictureBox22.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox22.TabIndex = 145
      Me.pictureBox22.TabStop = False
      '
      'pictureBox21
      '
      Me.pictureBox21.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox21.Location = New System.Drawing.Point(374, 470)
      Me.pictureBox21.Name = "pictureBox21"
      Me.pictureBox21.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox21.TabIndex = 144
      Me.pictureBox21.TabStop = False
      '
      'pictureBox20
      '
      Me.pictureBox20.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox20.Location = New System.Drawing.Point(284, 470)
      Me.pictureBox20.Name = "pictureBox20"
      Me.pictureBox20.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox20.TabIndex = 143
      Me.pictureBox20.TabStop = False
      '
      'pictureBox19
      '
      Me.pictureBox19.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox19.Location = New System.Drawing.Point(194, 470)
      Me.pictureBox19.Name = "pictureBox19"
      Me.pictureBox19.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox19.TabIndex = 142
      Me.pictureBox19.TabStop = False
      '
      'pictureBox18
      '
      Me.pictureBox18.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox18.Location = New System.Drawing.Point(104, 470)
      Me.pictureBox18.Name = "pictureBox18"
      Me.pictureBox18.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox18.TabIndex = 141
      Me.pictureBox18.TabStop = False
      '
      'pictureBox17
      '
      Me.pictureBox17.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox17.Location = New System.Drawing.Point(12, 470)
      Me.pictureBox17.Name = "pictureBox17"
      Me.pictureBox17.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox17.TabIndex = 140
      Me.pictureBox17.TabStop = False
      '
      'pictureBox16
      '
      Me.pictureBox16.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox16.Location = New System.Drawing.Point(374, 347)
      Me.pictureBox16.Name = "pictureBox16"
      Me.pictureBox16.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox16.TabIndex = 139
      Me.pictureBox16.TabStop = False
      '
      'pictureBox15
      '
      Me.pictureBox15.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox15.Location = New System.Drawing.Point(284, 347)
      Me.pictureBox15.Name = "pictureBox15"
      Me.pictureBox15.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox15.TabIndex = 138
      Me.pictureBox15.TabStop = False
      '
      'pictureBox14
      '
      Me.pictureBox14.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox14.Location = New System.Drawing.Point(194, 347)
      Me.pictureBox14.Name = "pictureBox14"
      Me.pictureBox14.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox14.TabIndex = 137
      Me.pictureBox14.TabStop = False
      '
      'pictureBox13
      '
      Me.pictureBox13.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox13.Location = New System.Drawing.Point(104, 347)
      Me.pictureBox13.Name = "pictureBox13"
      Me.pictureBox13.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox13.TabIndex = 136
      Me.pictureBox13.TabStop = False
      '
      'pictureBox12
      '
      Me.pictureBox12.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox12.Location = New System.Drawing.Point(14, 347)
      Me.pictureBox12.Name = "pictureBox12"
      Me.pictureBox12.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox12.TabIndex = 135
      Me.pictureBox12.TabStop = False
      '
      'pictureBox11
      '
      Me.pictureBox11.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox11.Location = New System.Drawing.Point(372, 178)
      Me.pictureBox11.Name = "pictureBox11"
      Me.pictureBox11.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox11.TabIndex = 134
      Me.pictureBox11.TabStop = False
      '
      'pictureBox10
      '
      Me.pictureBox10.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox10.Location = New System.Drawing.Point(282, 178)
      Me.pictureBox10.Name = "pictureBox10"
      Me.pictureBox10.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox10.TabIndex = 133
      Me.pictureBox10.TabStop = False
      '
      'pictureBox9
      '
      Me.pictureBox9.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox9.Location = New System.Drawing.Point(192, 178)
      Me.pictureBox9.Name = "pictureBox9"
      Me.pictureBox9.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox9.TabIndex = 132
      Me.pictureBox9.TabStop = False
      '
      'pictureBox8
      '
      Me.pictureBox8.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox8.Location = New System.Drawing.Point(102, 178)
      Me.pictureBox8.Name = "pictureBox8"
      Me.pictureBox8.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox8.TabIndex = 131
      Me.pictureBox8.TabStop = False
      '
      'pictureBox7
      '
      Me.pictureBox7.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox7.Location = New System.Drawing.Point(12, 178)
      Me.pictureBox7.Name = "pictureBox7"
      Me.pictureBox7.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox7.TabIndex = 130
      Me.pictureBox7.TabStop = False
      '
      'pictureBox6
      '
      Me.pictureBox6.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox6.Location = New System.Drawing.Point(462, 63)
      Me.pictureBox6.Name = "pictureBox6"
      Me.pictureBox6.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox6.TabIndex = 129
      Me.pictureBox6.TabStop = False
      '
      'pictureBox5
      '
      Me.pictureBox5.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox5.Location = New System.Drawing.Point(372, 63)
      Me.pictureBox5.Name = "pictureBox5"
      Me.pictureBox5.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox5.TabIndex = 128
      Me.pictureBox5.TabStop = False
      '
      'pictureBox4
      '
      Me.pictureBox4.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox4.Location = New System.Drawing.Point(282, 63)
      Me.pictureBox4.Name = "pictureBox4"
      Me.pictureBox4.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox4.TabIndex = 127
      Me.pictureBox4.TabStop = False
      '
      'pictureBox3
      '
      Me.pictureBox3.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox3.Location = New System.Drawing.Point(192, 63)
      Me.pictureBox3.Name = "pictureBox3"
      Me.pictureBox3.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox3.TabIndex = 126
      Me.pictureBox3.TabStop = False
      '
      'pictureBox2
      '
      Me.pictureBox2.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox2.Location = New System.Drawing.Point(102, 63)
      Me.pictureBox2.Name = "pictureBox2"
      Me.pictureBox2.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox2.TabIndex = 125
      Me.pictureBox2.TabStop = False
      '
      'pictureBox1
      '
      Me.pictureBox1.BackColor = System.Drawing.Color.LimeGreen
      Me.pictureBox1.Location = New System.Drawing.Point(12, 63)
      Me.pictureBox1.Name = "pictureBox1"
      Me.pictureBox1.Size = New System.Drawing.Size(72, 96)
      Me.pictureBox1.TabIndex = 124
      Me.pictureBox1.TabStop = False
      '
      'playerLabel
      '
      Me.playerLabel.AutoSize = True
      Me.playerLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.playerLabel.ForeColor = System.Drawing.Color.White
      Me.playerLabel.Location = New System.Drawing.Point(12, 295)
      Me.playerLabel.Name = "playerLabel"
      Me.playerLabel.Size = New System.Drawing.Size(172, 42)
      Me.playerLabel.TabIndex = 123
      Me.playerLabel.Text = "PLAYER"
      '
      'dealerLabel
      '
      Me.dealerLabel.AutoSize = True
      Me.dealerLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.dealerLabel.ForeColor = System.Drawing.Color.White
      Me.dealerLabel.Location = New System.Drawing.Point(12, 9)
      Me.dealerLabel.Name = "dealerLabel"
      Me.dealerLabel.Size = New System.Drawing.Size(174, 42)
      Me.dealerLabel.TabIndex = 122
      Me.dealerLabel.Text = "DEALER"
      '
      'Blackjack
      '
      Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
      Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
      Me.BackColor = System.Drawing.Color.LimeGreen
      Me.ClientSize = New System.Drawing.Size(693, 579)
      Me.Controls.Add(Me.playerTotalLabel)
      Me.Controls.Add(Me.dealerTotalLabel)
      Me.Controls.Add(Me.statusPictureBox)
      Me.Controls.Add(Me.stayButton)
      Me.Controls.Add(Me.hitButton)
      Me.Controls.Add(Me.dealButton)
      Me.Controls.Add(Me.pictureBox22)
      Me.Controls.Add(Me.pictureBox21)
      Me.Controls.Add(Me.pictureBox20)
      Me.Controls.Add(Me.pictureBox19)
      Me.Controls.Add(Me.pictureBox18)
      Me.Controls.Add(Me.pictureBox17)
      Me.Controls.Add(Me.pictureBox16)
      Me.Controls.Add(Me.pictureBox15)
      Me.Controls.Add(Me.pictureBox14)
      Me.Controls.Add(Me.pictureBox13)
      Me.Controls.Add(Me.pictureBox12)
      Me.Controls.Add(Me.pictureBox11)
      Me.Controls.Add(Me.pictureBox10)
      Me.Controls.Add(Me.pictureBox9)
      Me.Controls.Add(Me.pictureBox8)
      Me.Controls.Add(Me.pictureBox7)
      Me.Controls.Add(Me.pictureBox6)
      Me.Controls.Add(Me.pictureBox5)
      Me.Controls.Add(Me.pictureBox4)
      Me.Controls.Add(Me.pictureBox3)
      Me.Controls.Add(Me.pictureBox2)
      Me.Controls.Add(Me.pictureBox1)
      Me.Controls.Add(Me.playerLabel)
      Me.Controls.Add(Me.dealerLabel)
      Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.Name = "Blackjack"
      Me.Text = "Blackjack"
      Me.ResumeLayout(False)
      Me.PerformLayout()

   End Sub
   Private WithEvents playerTotalLabel As System.Windows.Forms.Label
   Private WithEvents dealerTotalLabel As System.Windows.Forms.Label
   Private WithEvents statusPictureBox As System.Windows.Forms.PictureBox
   Private WithEvents stayButton As System.Windows.Forms.Button
   Private WithEvents hitButton As System.Windows.Forms.Button
   Private WithEvents dealButton As System.Windows.Forms.Button
   Private WithEvents pictureBox22 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox21 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox20 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox19 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox18 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox17 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox16 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox15 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox14 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox13 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox12 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox11 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox10 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox9 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox8 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox7 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox6 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox5 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox4 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox3 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox2 As System.Windows.Forms.PictureBox
   Private WithEvents pictureBox1 As System.Windows.Forms.PictureBox
   Private WithEvents playerLabel As System.Windows.Forms.Label
   Private WithEvents dealerLabel As System.Windows.Forms.Label

End Class
